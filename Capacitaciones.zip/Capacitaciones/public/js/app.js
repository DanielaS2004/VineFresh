document.addEventListener('DOMContentLoaded', () => {
    const contenedor = document.getElementById('temas-seleccionados');

    if (!contenedor) return; // evita errores si no hay formulario

    // Manejo de selección de tarjetas
    document.querySelectorAll('.tema-card').forEach(card => {
        card.addEventListener('click', () => {
            const idTema = card.dataset.temaId;
            card.classList.toggle('selected');

            // input oculto asociado
            let inputExistente = contenedor.querySelector(`input[data-id-tema="${idTema}"]`);

            if (card.classList.contains('selected') && !inputExistente) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'temas[]';
                input.value = idTema;
                input.dataset.idTema = idTema;
                contenedor.appendChild(input);
            } else if (!card.classList.contains('selected') && inputExistente) {
                inputExistente.remove();
            }
        });
    });

    // Manejo de botón "Quitar" en lista de temas asignados
    document.querySelectorAll('.btn-remove-tema').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const li = e.target.closest('li');
            const idTema = li.dataset.idTema;

            // 1️⃣ quitar el input oculto
            const input = contenedor.querySelector(`input[data-id-tema="${idTema}"]`);
            if (input) input.remove();

            // 2️⃣ quitar la tarjeta marcada
            const card = document.querySelector(`.tema-card[data-tema-id="${idTema}"]`);
            if (card) card.classList.remove('selected');

            // 3️⃣ quitar el li de la lista
            li.remove();
        });
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.querySelector('.nav-bar ul');

    toggle.addEventListener('click', () => {
        menu.classList.toggle('show');
    });
});
