<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';
require_once 'models/Tema.php';
require_once 'models/Cargo.php';

class TemaController
{
    private $temaModel;
    private $db;

    public function __construct()
    {
        if (!isset($_SESSION['id_usuario'])) {
            header('Location: index.php?controller=Auth&action=login');
            exit;
        }

        $database = new Database();
        $this->db = $database->connect();

        $this->temaModel = new Tema($this->db);
    }

    /* ======================
       CRUD TEMAS
    ====================== */

    public function index()
    {
        $temas = $this->temaModel->obtenerTodos();

        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/temas/index.php';
        require_once 'views/layout/footer.php';
    }

    public function crear()
    {
        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/temas/form.php';
        require_once 'views/layout/footer.php';
    }

    public function guardar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nombre' => trim($_POST['nombre']),
                'descripcion' => trim($_POST['descripcion']),
                'estado' => 'activo'
            ];
            $this->temaModel->crear($data);
            header('Location: index.php?controller=Tema&action=index');
            exit;
        }
    }

    public function editar()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) die('ID inválido');

        $tema = $this->temaModel->obtenerPorId($id);

        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/temas/form.php';
        require_once 'views/layout/footer.php';
    }

    public function actualizar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'id' => $_POST['id_tema'],
                'nombre' => trim($_POST['nombre']),
                'descripcion' => trim($_POST['descripcion'])
            ];
            $this->temaModel->actualizar($data);
            header('Location: index.php?controller=Tema&action=index');
            exit;
        }
    }

    public function toggle()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) die('ID inválido');

        $tema = $this->temaModel->obtenerPorId($id);
        $nuevoEstado = ($tema['estado'] === 'activo') ? 'inactivo' : 'activo';

        $this->temaModel->cambiarEstado($id, $nuevoEstado);
        header('Location: index.php?controller=Tema&action=index');
        exit;
    }

    /* ======================
       ASIGNAR TEMAS A CARGOS
    ====================== */

    public function asignar()
{
    $cargoModel = new Cargo($this->db);
    $temasModel = new Tema($this->db);

    // Solo cargos activos
    $cargos = $cargoModel->obtenerActivos();
    // Solo temas activos
    $temas = $temasModel->obtenerActivos();

    $cargoSeleccionado = $_GET['cargo'] ?? null;
    $temasAsignados = [];

    if ($cargoSeleccionado) {
        $temasAsignados = $cargoModel->obtenerTemasAsignados($cargoSeleccionado);
    }

    require_once 'views/layout/header.php';
    require_once 'views/layout/sidebar.php';
    require_once 'views/temas/asignar.php';
    require_once 'views/layout/footer.php';
}

public function guardarAsignacion()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Location: index.php?controller=Tema&action=asignar');
        exit;
    }

    $idCargo = (int)($_POST['id_cargo'] ?? 0);
    $temasSeleccionados = $_POST['temas'] ?? [];

    if (!$idCargo) {
        $_SESSION['error'] = 'Cargo no válido';
        header('Location: index.php?controller=Tema&action=asignar');
        exit;
    }

    try {
        $this->db->beginTransaction();

        // Borrar asignaciones actuales
        $sqlDelete = "DELETE FROM capa_cargo_tema WHERE id_cargo = :id_cargo";
        $stmtDelete = $this->db->prepare($sqlDelete);
        $stmtDelete->bindParam(':id_cargo', $idCargo, PDO::PARAM_INT);
        $stmtDelete->execute();

        // Insertar nuevas asignaciones
        if (!empty($temasSeleccionados)) {
            $sqlInsert = "INSERT INTO capa_cargo_tema (id_cargo, id_tema) VALUES (:id_cargo, :id_tema)";
            $stmtInsert = $this->db->prepare($sqlInsert);

            foreach ($temasSeleccionados as $idTema) {
                $idTema = (int)$idTema;
                $stmtInsert->bindParam(':id_cargo', $idCargo, PDO::PARAM_INT);
                $stmtInsert->bindParam(':id_tema', $idTema, PDO::PARAM_INT);
                $stmtInsert->execute();
            }
        }

        $this->db->commit();
        $_SESSION['success'] = 'Asignaciones actualizadas correctamente';
        header("Location: index.php?controller=Tema&action=asignar&cargo=$idCargo");
        exit;

    } catch (Exception $e) {
        $this->db->rollBack();
        $_SESSION['error'] = 'Error al actualizar asignaciones: ' . $e->getMessage();
        header("Location: index.php?controller=Tema&action=asignar&cargo=$idCargo");
        exit;
    }
}

        }
