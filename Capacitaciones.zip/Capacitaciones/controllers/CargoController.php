<?php
// Iniciar sesión si no existe
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Dependencias
require_once 'config/database.php';
require_once 'models/Cargo.php';

class CargoController
{
    // Modelo Cargo
    private $cargoModel;

    // Constructor: conexión y modelo
    public function __construct()
    {
        $database = new Database();
        $db = $database->connect();
        $this->cargoModel = new Cargo($db);
    }

    // Listar cargos
    public function index()
    {
        $cargos = $this->cargoModel->obtenerTodos();
        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/cargos/index.php';
        require_once 'views/layout/footer.php';
    }

    // Mostrar formulario
    public function crear()
    {
        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/cargos/form.php';
        require_once 'views/layout/footer.php';
    }

    // Guardar cargo
    public function guardar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');

            if ($nombre === '') {
                $_SESSION['error'] = 'El nombre es obligatorio';
                header('Location: index.php?controller=Cargo&action=crear');
                exit;
            }

            $this->cargoModel->crear($nombre);
            $_SESSION['success'] = 'Cargo creado';
            header('Location: index.php?controller=Cargo&action=index');
            exit;
        }
    }

    // Editar cargo
    public function editar()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) die('ID no válido');

        $cargo = $this->cargoModel->obtenerPorId($id);
        require_once 'views/layout/header.php';
        require_once 'views/layout/sidebar.php';
        require_once 'views/cargos/form.php';
        require_once 'views/layout/footer.php';
    }

    // Actualizar cargo
    public function actualizar()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id_cargo'] ?? null;
            $nombre = trim($_POST['nombre'] ?? '');

            if (!$id || $nombre === '') {
                $_SESSION['error'] = 'Datos inválidos';
                header('Location: index.php?controller=Cargo&action=index');
                exit;
            }

            $this->cargoModel->actualizar($id, $nombre);
            $_SESSION['success'] = 'Cargo actualizado';
            header('Location: index.php?controller=Cargo&action=index');
            exit;
        }
    }

    // Activar / desactivar cargo
    public function toggle()
    {
        $id = $_GET['id'] ?? null;
        if (!$id) die('ID no válido');

        $cargo = $this->cargoModel->obtenerPorId($id);
        $nuevo_estado = ($cargo['estado'] === 'activo') ? 'inactivo' : 'activo';

        $this->cargoModel->actualizarEstado($id, $nuevo_estado);
        $_SESSION['success'] = 'Estado actualizado';
        header('Location: index.php?controller=Cargo&action=index');
        exit;
    }
}
