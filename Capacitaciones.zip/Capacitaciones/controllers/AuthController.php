<?php
// Inicia la sesión si no existe
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Conexión a la base de datos
require_once __DIR__ . "/../config/database.php";

class AuthController
{
    // Conexión PDO
    private $db;

    // Constructor: crea la conexión a la BD
    public function __construct()
    {
        $database = new Database();
        $this->db = $database->connect();
    }

    // Muestra el formulario de login
    public function login()
    {
        require_once 'views/auth/login.php';
    }

    // Autenticación del usuario
    public function authenticate()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $id_usuario = trim($_POST['id_usuario'] ?? '');

            // Validación básica
            if ($id_usuario === '') {
                $_SESSION['error'] = "Debes ingresar tu ID de usuario";
                header("Location: index.php?controller=Auth&action=login");
                exit;
            }

            // Consulta segura con PDO
            $stmt = $this->db->prepare(
                "SELECT * FROM capa_usuarios WHERE id_usuario = :id"
            );
            $stmt->bindParam(':id', $id_usuario, PDO::PARAM_INT);
            $stmt->execute();

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($usuario) {
                // Datos del usuario en sesión
                $_SESSION['id_usuario'] = $usuario['id_usuario'];
                $_SESSION['rol_id']     = $usuario['id_rol'];
                $_SESSION['id_cargo']   = $usuario['id_cargo'];

                // Redirección según rol
                if ($_SESSION['rol_id'] == 1) {
                    header("Location: index.php?controller=Cargo&action=index");
                } else {
                    echo "<h1>Bienvenido Usuario</h1>";
                }
                exit;
            }

            // Usuario no encontrado
            $_SESSION['error'] = "Usuario no encontrado";
            header("Location: index.php?controller=Auth&action=login");
            exit;
        }
    }

    // Cierra sesión
    public function logout()
    {
        session_destroy();
        header("Location: index.php?controller=Auth&action=login");
        exit;
    }
}
