DROP DATABASE IF EXISTS capa_modulo;
CREATE DATABASE capa_modulo
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE capa_modulo;

CREATE TABLE capa_roles (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(20) NOT NULL
);

CREATE TABLE capa_cargos (
    id_cargo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
);

CREATE TABLE capa_usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario_empresa INT NOT NULL,
    id_cargo INT NOT NULL,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_cargo) REFERENCES capa_cargos(id_cargo),
    FOREIGN KEY (id_rol) REFERENCES capa_roles(id_rol)
);

CREATE TABLE capa_temas (
    id_tema INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    estado VARCHAR(20)
);

CREATE TABLE capa_cargo_tema (
    id_cargo INT NOT NULL,
    id_tema INT NOT NULL,
    PRIMARY KEY (id_cargo, id_tema),
    FOREIGN KEY (id_cargo) REFERENCES capa_cargos(id_cargo),
    FOREIGN KEY (id_tema) REFERENCES capa_temas(id_tema)
);

CREATE TABLE capa_capacitaciones (
    id_capacitacion INT AUTO_INCREMENT PRIMARY KEY,
    id_tema INT NOT NULL,
    archivo VARCHAR(200),
    titulo VARCHAR(150) NOT NULL,
    url VARCHAR(255),
    estado VARCHAR(20),
    FOREIGN KEY (id_tema) REFERENCES capa_temas(id_tema)
);

CREATE TABLE capa_preguntas (
    id_pregunta INT AUTO_INCREMENT PRIMARY KEY,
    id_capacitaciones INT NOT NULL,
    enunciado TEXT NOT NULL,
    estado VARCHAR(20),
    FOREIGN KEY (id_capacitaciones) REFERENCES capa_capacitaciones(id_capacitacion)
);

CREATE TABLE capa_opciones (
    id_opcion INT AUTO_INCREMENT PRIMARY KEY,
    id_pregunta INT NOT NULL,
    texto TEXT NOT NULL,
    valor INT NOT NULL,
    estado VARCHAR(20),
    FOREIGN KEY (id_pregunta) REFERENCES capa_preguntas(id_pregunta)
);

CREATE TABLE capa_evaluaciones (
    id_evaluaciones INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_capacitaciones INT NOT NULL,
    puntaje_total INT,
    porcentaje INT,
    resultado VARCHAR(20),
    intento INT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES capa_usuarios(id_usuario),
    FOREIGN KEY (id_capacitaciones) REFERENCES capa_capacitaciones(id_capacitacion)
);

CREATE TABLE capa_respuestas_usuario (
    id_respuesta INT AUTO_INCREMENT PRIMARY KEY,
    id_evaluacion INT NOT NULL,
    id_pregunta INT NOT NULL,
    id_opcion INT NOT NULL,
    valor INT,
    FOREIGN KEY (id_evaluacion) REFERENCES capa_evaluaciones(id_evaluaciones),
    FOREIGN KEY (id_pregunta) REFERENCES capa_preguntas(id_pregunta),
    FOREIGN KEY (id_opcion) REFERENCES capa_opciones(id_opcion)
);
