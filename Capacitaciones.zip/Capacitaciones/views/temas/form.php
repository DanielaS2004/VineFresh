<?php
$editar = isset($tema);
?>

<?php require_once 'views/layout/header.php'; ?>
<?php require_once 'views/layout/sidebar.php'; ?>

<main class="content">
    <div class="page-header">
        <h1><?= $editar ? 'Editar tema' : 'Nuevo tema' ?></h1>
    </div>

    <form method="POST" action="index.php?controller=tema&action=<?= $editar ? 'actualizar' : 'guardar' ?>">
        <?php if ($editar): ?>
            <input type="hidden" name="id_tema" value="<?= $tema['id_tema'] ?>">
        <?php endif; ?>

        <div class="form-group">
            <label>Nombre</label>
            <input type="text" name="nombre" required value="<?= $editar ? $tema['nombre'] : '' ?>">
        </div>

        <div class="form-group">
            <label>Descripción</label>
            <textarea name="descripcion"><?= $editar ? $tema['descripcion'] : '' ?></textarea>
        </div>

        <button class="btn-primary">Guardar</button>
        <a href="index.php?controller=tema" class="btn-cancel">Cancelar</a>
    </form>
</main>

<?php require_once 'views/layout/footer.php'; ?>
