<div class="card form-card">
    <h2>Asignar Temas a Cargos</h2>

    <!-- Seleccionar cargo -->
    <form method="GET" action="index.php">
        <input type="hidden" name="controller" value="Tema">
        <input type="hidden" name="action" value="asignar">
        <div class="form-group">
            <label>Cargo</label>
            <select name="cargo" onchange="this.form.submit()" required>
                <option value="">Seleccione un cargo</option>
                <?php foreach ($cargos as $cargo): ?>
                    <?php if($cargo['estado'] === 'activo'): // solo activos ?>
                        <option value="<?= $cargo['id_cargo'] ?>" <?= ($cargoSeleccionado == $cargo['id_cargo']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cargo['nombre']) ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <?php if (!empty($cargoSeleccionado)): ?>
        <form method="POST" action="index.php?controller=Tema&action=guardarAsignacion">
            <input type="hidden" name="id_cargo" value="<?= $cargoSeleccionado ?>">

            <!-- Lista de temas asignados (solo quitar) -->
            <div class="asignados">
                <h3>Temas asignados a este cargo</h3>
                <?php if (!empty($temasAsignados)): ?>
                    <ul>
                        <?php foreach ($temasAsignados as $idTema):
                            $temaInfo = array_values(array_filter($temas, fn($t) => $t['id_tema'] == $idTema))[0] ?? null;
                            if (!$temaInfo) continue; // si el tema ya no está activo, saltar
                        ?>
                            <li data-id-tema="<?= $idTema ?>">
                                <?= htmlspecialchars($temaInfo['nombre']) ?>
                                <button type="button" class="btn-remove-tema">Quitar</button>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No hay temas asignados todavía.</p>
                <?php endif; ?>
            </div>

            <!-- Todos los temas disponibles -->
            <label class="mt-20">Temas disponibles</label>
            <div class="temas-grid">
                <?php foreach ($temas as $tema):
                    $asignado = in_array($tema['id_tema'], $temasAsignados);
                ?>
                    <div class="tema-card <?= $asignado ? 'selected' : '' ?>" data-tema-id="<?= $tema['id_tema'] ?>">
                        <h4><?= htmlspecialchars($tema['nombre']) ?></h4>
                        <p><?= htmlspecialchars($tema['descripcion']) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Inputs ocultos para el POST -->
            <div id="temas-seleccionados">
                <?php foreach ($temasAsignados as $idTema): ?>
                    <input type="hidden" name="temas[]" value="<?= $idTema ?>" data-id-tema="<?= $idTema ?>">
                <?php endforeach; ?>
            </div>

            <div style="margin-top:30px; text-align:center;">
                <button type="submit" class="btn-primary">Guardar asignación</button>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const contenedor = document.getElementById('temas-seleccionados');
    if (!contenedor) return;

    // Manejo de selección de tarjetas
    document.querySelectorAll('.tema-card').forEach(card => {
        card.addEventListener('click', () => {
            const idTema = card.dataset.temaId;
            card.classList.toggle('selected');

            let inputExistente = contenedor.querySelector(`input[data-id-tema="${idTema}"]`);
            if (card.classList.contains('selected') && !inputExistente) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'temas[]';
                input.value = idTema;
                input.dataset.idTema = idTema;
                contenedor.appendChild(input);
            } else if (!card.classList.contains('selected') && inputExistente) {
                inputExistente.remove();
            }
        });
    });

    // Manejo de botón "Quitar"
    document.querySelectorAll('.btn-remove-tema').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const li = e.target.closest('li');
            const idTema = li.dataset.idTema;

            // 1️⃣ quitar input oculto
            const input = contenedor.querySelector(`input[data-id-tema="${idTema}"]`);
            if (input) input.remove();

            // 2️⃣ quitar la tarjeta marcada
            const card = document.querySelector(`.tema-card[data-tema-id="${idTema}"]`);
            if (card) card.classList.remove('selected');

            // 3️⃣ quitar el li de la lista
            li.remove();
        });
    });
});
</script>
