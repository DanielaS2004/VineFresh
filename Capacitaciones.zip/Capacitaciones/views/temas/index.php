<?php require_once 'views/layout/header.php'; ?>

<main class="main-content">

    <div class="page-header">
        <h1>Temas</h1>
        <a href="index.php?controller=Tema&action=crear" class="btn-primary">
            + Nuevo tema
        </a>
    </div>

    <?php if (!empty($temas)) : ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th style="width: 200px;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($temas as $tema): ?>
                    <tr>
                        <td><?= htmlspecialchars($tema['nombre']); ?></td>
                        <td><?= htmlspecialchars($tema['descripcion']); ?></td>
                        <td class="actions">

                            <a class="btn-edit"
                               href="index.php?controller=Tema&action=editar&id=<?= $tema['id_tema']; ?>">
                                Editar
                            </a>

                            <?php if ($tema['estado'] === 'activo'): ?>
                                <a class="btn-delete"
                                   href="index.php?controller=Tema&action=toggle&id=<?= $tema['id_tema']; ?>">
                                    Inactivar
                                </a>
                            <?php else: ?>
                                <a class="btn-edit"
                                   href="index.php?controller=Tema&action=toggle&id=<?= $tema['id_tema']; ?>">
                                    Activar
                                </a>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php else: ?>

        <div class="card empty-dashboard">
            <div class="empty-icon">📚</div>
            <h3>Gestión de temas</h3>
            <p>Aún no se han creado temas de capacitación.</p>

            <a href="index.php?controller=Tema&action=crear" class="btn-primary">
                Crear primer tema
            </a>
        </div>

    <?php endif; ?>

</main>

<?php require_once 'views/layout/footer.php'; ?>
