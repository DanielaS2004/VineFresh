<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login | Global Life</title>
</head>
<body>
<h2>Login de Usuario</h2>

<?php if (!empty($_SESSION['error'])): ?>
    <p style="color:red"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
<?php endif; ?>

<form method="POST" action="index.php?controller=Auth&action=authenticate">
    <label for="id_usuario">ID Usuario:</label>
    <input type="number" name="id_usuario" id="id_usuario" required>
    <button type="submit">Ingresar</button>
</form>
</body>
</html>
