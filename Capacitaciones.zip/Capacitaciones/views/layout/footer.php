</main> <!-- Cierra main-content -->
</div> <!-- Cierra app-container -->

<footer class="footer">
    <p>© <?= date('Y') ?> Global Life Ambulancias SAS</p>
</footer>
<script src="public/js/app.js"></script>
</body>
</html>

