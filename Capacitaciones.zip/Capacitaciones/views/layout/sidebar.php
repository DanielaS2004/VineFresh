<aside class="sidebar">
    <div class="sidebar-header">Global Life</div>
    <ul class="menu">
        <!-- Cargos -->
        <li>
            <a href="javascript:void(0)">Cargos</a>
            <ul class="submenu">
                <li><a href="index.php?controller=Cargo&action=index">Gestionar Cargos</a></li>
            </ul>
        </li>

        <!-- Temas -->
        <li>
            <a href="javascript:void(0)">Temas</a>
            <ul class="submenu">
                <li><a href="index.php?controller=Tema&action=index">Gestionar Temas</a></li>
                <li><a href="index.php?controller=Tema&action=asignar">Asignar Temas a Cargos</a></li>
            </ul>
        </li>

        <!-- Capacitaciones -->
        <li>
            <a href="javascript:void(0)">Capacitaciones</a>
            <ul class="submenu">
                <li><a href="index.php?controller=Capacitacion&action=index">Gestionar Capacitaciones</a></li>
            </ul>
        </li>

        <!-- Preguntas -->
        <li>
            <a href="javascript:void(0)">Preguntas</a>
            <ul class="submenu">
                <li><a href="index.php?controller=Pregunta&action=index">Gestionar Preguntas</a></li>
            </ul>
        </li>

        <!-- Evaluaciones -->
        <li>
            <a href="javascript:void(0)">Evaluaciones</a>
            <ul class="submenu">
                <li><a href="index.php?controller=Evaluacion&action=index">Ver Resultados</a></li>
            </ul>
        </li>

        <!-- Logout -->
        <li class="logout">
            <a href="index.php?controller=Auth&action=logout">Cerrar sesión</a>
        </li>
    </ul>
</aside>

<main class="main-content">
    <!-- Contenido de la página -->
</main>
