<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Life</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>

<header class="header">
    <div class="logo">Global Life</div>
    <nav class="nav-bar">
        <ul>
            <li><a href="index.php?controller=Cargo&action=index">Cargos</a></li>
            <li>
                <a href="#">Temas</a>
                <ul class="dropdown">
                    <li><a href="index.php?controller=Tema&action=index">Gestionar Temas</a></li>
                    <li><a href="index.php?controller=Tema&action=asignar">Asignar Temas a Cargos</a></li>
                </ul>
            </li>
            <li><a href="index.php?controller=Capacitacion&action=index">Capacitaciones</a></li>
            <li><a href="index.php?controller=Pregunta&action=index">Preguntas</a></li>
            <li><a href="index.php?controller=Evaluacion&action=index">Evaluaciones</a></li>
            <li><a href="index.php?controller=Auth&action=logout">Cerrar sesión</a></li>
        </ul>
        <button class="nav-toggle" aria-label="Abrir menú">☰</button>
    </nav>
</header>

<main class="main-container">
