<?php
$editar = isset($cargo);
?>

<div class="card form-card">
    <form method="POST"
          action="index.php?controller=Cargo&action=<?= $editar ? 'actualizar' : 'guardar'; ?>">

        <?php if ($editar): ?>
            <input type="hidden" name="id_cargo" value="<?= $cargo['id_cargo']; ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="nombre">Nombre del cargo</label>
            <input type="text"
                   id="nombre"
                   name="nombre"
                   required
                   placeholder="Ej: Conductor de Ambulancia"
                   value="<?= $editar ? htmlspecialchars($cargo['nombre']) : ''; ?>">
        </div>

        <div class="form-actions">
            <button type="submit" class="btn-primary">
                <?= $editar ? 'Actualizar cargo' : 'Guardar cargo'; ?>
            </button>
            <a href="index.php?controller=Cargo&action=index" class="btn-cancel">
                Cancelar
            </a>
        </div>

    </form>
</div>
