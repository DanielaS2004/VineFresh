<?php require_once 'views/layout/header.php'; ?>

<main class="main-content">

    <div class="page-header">
        <h1>Cargos</h1>
        <a href="index.php?controller=Cargo&action=crear" class="btn-primary">+ Nuevo cargo</a>
    </div>

    <?php if (!empty($cargos)) : ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Cargo</th>
                    <th style="width: 180px;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cargos as $cargo): ?>
                    <tr>
                        <td><?= htmlspecialchars($cargo['nombre']); ?></td>
                        <td class="actions">
                            <a class="btn-edit"
                               href="index.php?controller=Cargo&action=editar&id=<?= $cargo['id_cargo']; ?>">Editar</a>

                            <?php if ($cargo['estado'] === 'activo'): ?>
                                <a class="btn-delete"
                                   href="index.php?controller=Cargo&action=toggle&id=<?= $cargo['id_cargo']; ?>">
                                   Inactivar
                                </a>
                            <?php else: ?>
                                <a class="btn-edit"
                                   href="index.php?controller=Cargo&action=toggle&id=<?= $cargo['id_cargo']; ?>">
                                   Activar
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="card empty-dashboard">
            <div class="empty-icon">🏥</div>
            <h3>Gestión de cargos</h3>
            <p>Aún no se han definido cargos dentro del sistema de capacitación.</p>
            <a href="index.php?controller=Cargo&action=crear" class="btn-primary">Registrar cargo</a>
        </div>
    <?php endif; ?>

</main>

<?php require_once 'views/layout/footer.php'; ?>
