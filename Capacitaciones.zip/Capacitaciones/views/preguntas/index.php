<?php include 'views/layout/header.php'; ?>
<?php include 'views/layout/sidebar.php'; ?>

<main class="content">
    <h1>Preguntas</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Pregunta</th>
                <th>Capacitación</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($preguntas as $p): ?>
            <tr>
                <td><?= $p['enunciado'] ?></td>
                <td><?= $p['titulo'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'views/layout/footer.php'; ?>
