<?php include 'views/layout/header.php'; ?>
<?php include 'views/layout/sidebar.php'; ?>

<main class="content">
    <h1>Resultados de Evaluaciones</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Usuario</th>
                <th>Capacitación</th>
                <th>Puntaje</th>
                <th>Resultado</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($evaluaciones as $e): ?>
            <tr>
                <td><?= $e['id_usuario'] ?></td>
                <td><?= $e['titulo'] ?></td>
                <td><?= $e['puntaje_total'] ?></td>
                <td><?= $e['resultado'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'views/layout/footer.php'; ?>
