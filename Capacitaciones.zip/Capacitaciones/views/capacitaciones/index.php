<?php include 'views/layout/header.php'; ?>
<?php include 'views/layout/sidebar.php'; ?>

<main class="content">
    <div class="content-header">
        <h1>Capacitaciones</h1>
        <a href="index.php?controller=capacitacion&action=form" class="btn">Nueva Capacitación</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Tema</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($capacitaciones as $c): ?>
            <tr>
                <td><?= $c['titulo'] ?></td>
                <td><?= $c['tema'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'views/layout/footer.php'; ?>
