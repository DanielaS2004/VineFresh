<?php

class Tema
{
    private $conn;
    private $table = "capa_temas";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    /* ======================
       CRUD TEMAS
    ====================== */

    // Todos los temas (para gestión)
    public function obtenerTodos()
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY id_tema DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Solo activos (para asignación)
    public function obtenerActivos()
    {
        $sql = "SELECT * FROM {$this->table} WHERE estado = 'activo' ORDER BY id_tema DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id_tema = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function crear($data)
    {
        $sql = "INSERT INTO {$this->table} (nombre, descripcion, estado)
                VALUES (:nombre, :descripcion, :estado)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($data);
    }

    public function actualizar($data)
    {
        $sql = "UPDATE {$this->table} SET nombre = :nombre, descripcion = :descripcion WHERE id_tema = :id";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($data);
    }

    public function cambiarEstado($id, $estado)
    {
        $sql = "UPDATE {$this->table} SET estado = :estado WHERE id_tema = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':estado', $estado);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
