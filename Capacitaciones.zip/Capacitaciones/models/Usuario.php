<?php
class Usuario {

    private $conn;
    private $table = "capa_usuarios";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function buscarPorIdEmpresa($idEmpresa) {
        $sql = "SELECT * FROM $this->table 
                WHERE id_usuario_empresa = :id 
                LIMIT 1";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute(['id' => $idEmpresa]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
