<?php

class Cargo
{
    private $conn;
    private $table = "capa_cargos";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    /* ======================
       CRUD BÁSICO
    ====================== */

    // Todos los cargos (para gestión)
    public function obtenerTodos()
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY id_cargo DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Solo activos (para asignación de temas)
    public function obtenerActivos()
    {
        $sql = "SELECT * FROM {$this->table} WHERE estado = 'activo' ORDER BY id_cargo DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id_cargo = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function crear($nombre)
    {
        $sql = "INSERT INTO {$this->table} (nombre, estado)
                VALUES (:nombre, 'activo')";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        return $stmt->execute();
    }

    public function actualizar($id, $nombre)
    {
        $sql = "UPDATE {$this->table} SET nombre = :nombre WHERE id_cargo = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function actualizarEstado($id, $estado)
    {
        $sql = "UPDATE {$this->table} SET estado = :estado WHERE id_cargo = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':estado', $estado);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /* ======================
       ASIGNAR TEMAS A CARGOS
    ====================== */

    public function obtenerTemasAsignados($idCargo)
    {
        $sql = "SELECT tc.id_tema
                FROM capa_cargo_tema tc
                INNER JOIN capa_temas t ON t.id_tema = tc.id_tema
                WHERE tc.id_cargo = :id AND t.estado = 'activo'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $idCargo, PDO::PARAM_INT);
        $stmt->execute();
        return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'id_tema');
    }

    public function asignarTemas($idCargo, $temas)
    {
        // Eliminar asignaciones previas
        $sqlDelete = "DELETE FROM capa_cargo_tema WHERE id_cargo = :id";
        $stmtDelete = $this->conn->prepare($sqlDelete);
        $stmtDelete->bindParam(':id', $idCargo, PDO::PARAM_INT);
        $stmtDelete->execute();

        // Insertar nuevas asignaciones
        if (!empty($temas)) {
            $sqlInsert = "INSERT INTO capa_cargo_tema (id_cargo, id_tema) VALUES (:cargo, :tema)";
            $stmtInsert = $this->conn->prepare($sqlInsert);

            foreach ($temas as $idTema) {
                $idTema = (int)$idTema;
                $stmtInsert->execute([
                    ':cargo' => $idCargo,
                    ':tema' => $idTema
                ]);
            }
        }
    }
}
