<?php
// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Controller y action
$controller = $_GET['controller'] ?? 'auth';
$action     = $_GET['action'] ?? null;

// Normalizar nombre
$controllerName = ucfirst(strtolower($controller)) . 'Controller';
$controllerFile = __DIR__ . "/controllers/$controllerName.php";

// Validar controlador
if (!file_exists($controllerFile)) {
    die("Controlador no encontrado: $controllerName");
}

require_once $controllerFile;
$c = new $controllerName();

// 🔑 Lógica inteligente de acción
if ($action === null) {
    // Si es Auth, va a login
    $action = ($controller === 'auth') ? 'login' : 'index';
}

// Validar acción
if (!method_exists($c, $action)) {
    die("Acción no encontrada: $action");
}

// Ejecutar acción
$c->$action();
